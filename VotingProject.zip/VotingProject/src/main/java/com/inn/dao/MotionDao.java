package com.inn.dao;

import java.util.List;

import com.inn.model.Motion;
import com.inn.model.Voter;

public interface MotionDao {

	
public void save(Motion motion);
	
	public void update(Motion motion);
	
	public void delete(Motion motion);
	
	public Motion find(Motion motion);

	List<Motion> getMotionsByOpenStatus();

	List<Motion[]> getMotionStateById(Integer id);

	List<Motion> getMotionResult();
}
