package com.inn.dao;

import com.inn.model.Voter;

public interface VoterDao {

	public void save(Voter voter);
	
	public void update(Voter voter);
	
	public void delete(Voter voter);
	
	public void find(Voter voter);
}
