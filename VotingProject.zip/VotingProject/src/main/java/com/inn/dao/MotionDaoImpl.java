package com.inn.dao;

import java.util.List;

import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.inn.model.Motion;

public class MotionDaoImpl extends HibernateDaoSupport implements MotionDao{

	@Override
	public void save(Motion motion) {
		// TODO Auto-generated method stub
		getHibernateTemplate().save(motion);
	}

	@Override
	public void update(Motion motion) {
		// TODO Auto-generated method stub
		getHibernateTemplate().update(motion);
	}

	@Override
	public void delete(Motion motion) {
		// TODO Auto-generated method stub
		getHibernateTemplate().delete(motion);
	}

	@Override
	public Motion find(Motion motion) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Motion> getMotionsByOpenStatus(){
	
		List list=getHibernateTemplate().findByNamedQuery("select m.id,m.motionName from Motion m Where m.mostionState = 'In_progress'");
		return list;
	}
	
	@Override
	public List<Motion[]> getMotionStateById(Integer id){
	
		List list=getHibernateTemplate().findByNamedQuery("select m.mostionState from Motion m Where m.mostionState ="+id);
		return list;
	}

	@Override
	public List<Motion> getMotionResult(){
	
		List list=getHibernateTemplate().find(" from Motion m ");
		return list;
	}
}
