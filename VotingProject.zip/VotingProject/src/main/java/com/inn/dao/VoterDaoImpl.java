package com.inn.dao;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.inn.model.Voter;

public class VoterDaoImpl extends HibernateDaoSupport implements VoterDao{

	/*private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}*/
	
	@Override
	public void save(Voter channel) {
		getHibernateTemplate().save(channel);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Voter channel) {
		getHibernateTemplate().update(channel);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Voter channel) {
		getHibernateTemplate().delete(channel);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void find(Voter channel) {
		getHibernateTemplate().find("");
		// TODO Auto-generated method stub
		
	}

}
