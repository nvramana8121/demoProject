package com.inn.rest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.inn.model.Motion;
import com.inn.model.Motion.MotionState;
import com.inn.model.Voter;
import com.inn.model.Voter.RoleOfVoter;
import com.inn.service.MotionService;
import com.inn.service.MotionServiceImpl;
import com.inn.service.VoterService;
import com.inn.service.VoterServiceImpl;

/**
 * Hello world!
 *
 */
/**
 * @author ist
 *
 */
public class RestForVoter
{
    
	
	
	private MotionService motionService;
	
	
	public void setMotionService(MotionService motionService) {
		this.motionService = motionService;
	}


	private VoterService voterService;
	
	public void setVoterService(VoterService voterService) {
		this.voterService = voterService;
	}

	//with mian i tryed
	public static void main( String[] args )
    {
       ApplicationContext applicationContext=new ClassPathXmlApplicationContext("configure.xml");
       MotionService motionService =applicationContext.getBean(MotionServiceImpl.class);
       Motion motion=new Motion();
       motion.setName("motion1");
       VoterService voterService1=applicationContext.getBean(VoterServiceImpl.class);
       Voter voter=new Voter();
       voter.setRoleOfVoter(RoleOfVoter.Normal_Citizen);
       voter.setVoterId("1");
       Set<Voter> voters=new HashSet<Voter>();
       voters.add(voter);
       motionService.save(motion);
       //voterService1.save(voter);
       
    }
	
	/** this method for saving voters who voted and motion checking parellelly */
    
    @RequestMapping(value="/save",method=RequestMethod.POST,produces={"application,json/application-xml"}, consumes="application/json")
    public ModelAndView saveVoterWhoVoted(@ModelAttribute("voter") Voter voter){
    	
    	if(voter != null){
    		try{
    			
    			//this method will throw the exception if already voter exists with same voterId
    			voterService.save(voter);
	    		}catch(Exception e){
	    			return new ModelAndView("voter exits");
	    		}
    		}
    		if(voter.getRoleOfVoter().equals(Voter.RoleOfVoter.Speaker)){
    			List list=motionService.getMotionsByOpenStatus();
    			if(!list.isEmpty()){
    				Motion motion=(Motion) list.get(0);
    				Set<Voter> voters=motion.getVoters();
    				voters.add(voter);
    				if(voters.size() == 51){
    					//checked the motion and state changed;
    			    	if(motion.getMostionState().equals(MotionState.Tied))
    			    	{
    			    		return new ModelAndView("motion tied speaker need to vote now");
    			    	}else{
    			    		return new ModelAndView("motion closed to create new motion");
    			    	}
    				}
    			}
    		}
    	
    	
    	return new ModelAndView("Voter voted successfully");
    	
    }
    
    /**This method for saving Motion */
    @RequestMapping(value="/saveMotion",method=RequestMethod.POST,produces={"application,json/application-xml"}, consumes="application/json")
    public ModelAndView saveMotion(@ModelAttribute("motion") Motion motion){
    	
    	if(motion != null){
    		try{
    			//here check the save motion
    			 motionService.save(motion);
	    		}catch(Exception e){
	    			return new ModelAndView("voter exits");
	    		}
    		}
    	return new ModelAndView("motion created successfully");
    	
    }
    
    @RequestMapping(value="/getMotionStatus",method=RequestMethod.GET)
    public List<Motion[]> getMotionStatus(@ModelAttribute("motionId") Integer motionId){
    	
    	if(motionId != null){
    		try{
    			//here check the save motion
    			return motionService.getMotionStateById(motionId);
	    		}catch(Exception e){
	    			e.printStackTrace();
	    		}
    		}
		return null;
    	
    }
    
    @RequestMapping(value="/getMotionStateById",method=RequestMethod.GET)
    public List getMotionStateById(@ModelAttribute("motionId") Integer motionId){
    	
    	if(motionId != null){
    		try{
    			//here check the save motion
    			return motionService.getMotionStateById(motionId);
	    		}catch(Exception e){
	    			e.printStackTrace();
	    		}
    		}
    	return null;
    	
    }
    
    
    
 }
