package com.inn.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.inn.dao.VoterDao;
import com.inn.model.Voter;

public class VoterServiceImpl implements VoterService{
	
	private VoterDao voterDao;

	

	public void setVoterDao(VoterDao voterDao) {
		this.voterDao = voterDao;
	}

	@Override
	public void save(Voter voter) {
		// TODO Auto-generated method stub
		voterDao.save(voter);
		
	}

	@Override
	public void update(Voter voter) {
		// TODO Auto-generated method stub
		voterDao.update(voter);
		
	}

	@Override
	public void delete(Voter voter) {
		// TODO Auto-generated method stub
		voterDao.delete(voter);
		
	}

	@Override
	public void find(Voter channel) {
		// TODO Auto-generated method stub
		
	}

}
