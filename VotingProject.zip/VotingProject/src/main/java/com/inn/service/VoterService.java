package com.inn.service;

import com.inn.model.Voter;

public interface VoterService {

	public void save(Voter voter);
	
	public void update(Voter voter);
	
	public void delete(Voter voter);
	
	public void find(Voter voter);
}
