package com.inn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.inn.dao.MotionDao;
import com.inn.model.Motion;

public class MotionServiceImpl implements MotionService{

	private MotionDao motionDao;
	

	public void setMotionDao(MotionDao motionDao) {
		this.motionDao = motionDao;
	}

	@Override
	public void save(Motion motion) {
		// TODO Auto-generated method stub
		motionDao.save(motion);
	}

	@Override
	public void update(Motion motion) {
		// TODO Auto-generated method stub
		motionDao.update(motion);
	}

	@Override
	public void delete(Motion motion) {
		// TODO Auto-generated method stub
		motionDao.delete(motion);
	}

	@Override
	public Motion find(Motion motion) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Motion> getMotionsByOpenStatus() {
		return motionDao.getMotionsByOpenStatus();
	}

	@Override
	public List<Motion[]> getMotionStateById(Integer id) {
		// TODO Auto-generated method stub
		return motionDao.getMotionStateById(id);
	}

	@Override
	public List<Motion> getMotionResult() {
		// TODO Auto-generated method stub
		return motionDao.getMotionResult();
	}

}
