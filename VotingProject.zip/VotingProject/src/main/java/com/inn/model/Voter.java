package com.inn.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.inn.model.Motion.MotionState;

@Entity
@Table(name="voter")
public class Voter implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer voter_id;
	
	private String name;
	
	@Column(unique=true)
	private String voterId;
	
	@Enumerated(EnumType.STRING)
	private RoleOfVoter roleOfVoter;
	
	public String getVoterId() {
		return voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}

	public RoleOfVoter getRoleOfVoter() {
		return roleOfVoter;
	}

	public void setRoleOfVoter(RoleOfVoter roleOfVoter) {
		this.roleOfVoter = roleOfVoter;
	}

	public static enum RoleOfVoter{
		Speaker,
		Normal_Citizen
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
