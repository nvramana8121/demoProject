package com.inn.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table
public class Motion {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer member_id;
	
	private String name;
	
	@OneToMany(targetEntity=Voter.class)
	@JoinColumn(name="voter_id")
	private Set<Voter> voters=new HashSet<Voter>();
	
	

	public Set<Voter> getVoters() {
		return voters;
	}

	public void setVoters(Set<Voter> voters) {
		this.voters = voters;
	}

	@Column(unique=true)
	private String phno;

	@Enumerated(EnumType.STRING)
	private MotionState mostionState;
	
	public static enum MotionState{
		Not_Started,In_progress,
		Completed, Tied, Void
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	public MotionState getMostionState() {
		return mostionState;
	}

	public void setMostionState(MotionState mostionState) {
		this.mostionState = mostionState;
	}

	
	
	
}
